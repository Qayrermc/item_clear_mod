import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.player.PlayerTickCallback;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.ChestScreenHandler;
import net.minecraft.server.MinecraftServer;
import net.minecraft.text.LiteralText;
import net.minecraft.world.World;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

public class ItemClearMod implements ModInitializer {
    public static final Logger LOGGER = LogManager.getLogger("item_clear_mod");

    private static final int CLEAR_INTERVAL = 30 * 60 * 1000; // 30 phút
    private static final int WARNING_TIME = 60 * 1000; // 1 phút
    private static final int COUNTDOWN_TIME = 10 * 1000; // 10 giây

    private Timer timer;
    private boolean isCountingDown = false;

    @Override
    public void onInitialize() {
        timer = new Timer();
        scheduleItemClear();

        PlayerTickCallback.EVENT.register((player) -> {
            if (isCountingDown && isPlayerInChest(player)) {
                // Chặn vứt vật phẩm và hiển thị thông báo
                player.dropItem(false); // Hủy bỏ hành động vứt vật phẩm
                player.sendMessage(new LiteralText("Bạn không thể vứt vật phẩm trong thời gian này."), false);
            }
        });
    }

    private void scheduleItemClear() {
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                MinecraftServer server = MinecraftServer.getServer();
                if (server != null) {
                    World overworld = server.getOverworld();
                    if (overworld != null) {
                        LOGGER.info("Starting item clearing...");
                        server.getPlayerManager().broadcast(new LiteralText("Sắp tới, tất cả các vật phẩm trên mặt đất sẽ bị xóa."));

                        timer.schedule(new TimerTask() {
                            @Override
                            public void run() {
                                server.getPlayerManager().broadcast(new LiteralText("Vật phẩm sẽ bị xóa trong 1 phút."));
                                scheduleCountdown(overworld);
                            }
                        }, CLEAR_INTERVAL - WARNING_TIME);
                    }
                }
            }
        }, CLEAR_INTERVAL);
    }

    private void scheduleCountdown(World world) {
        isCountingDown = true;
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                for (int i = 10; i > 0; i--) {
                    try {
                        Thread.sleep(1000);
                        MinecraftServer server = MinecraftServer.getServer();
                        if (server != null) {
                            server.getPlayerManager().broadcast(new LiteralText("Vật phẩm sẽ bị xóa trong " + i + " giây."));
                        }
                    } catch (InterruptedException e) {
                        LOGGER.error("Countdown interrupted: " + e.getMessage());
                    }
                }
                clearItems(world);
                isCountingDown = false;
            }
        }, CLEAR_INTERVAL - COUNTDOWN_TIME);
    }

    private void clearItems(World world) {
        List<ItemEntity> items = world.getEntities(ItemEntity.class, entity -> true);
        int itemCount = items.size();
        for (ItemEntity item : items) {
            item.remove(ItemEntity.RemovalReason.KILLED);
        }

        MinecraftServer server = MinecraftServer.getServer();
        if (server != null) {
            server.getPlayerManager().broadcast(new LiteralText("Đã xóa " + itemCount + " vật phẩm trên mặt đất."));
        }
        LOGGER.info("Item clearing completed.");
        scheduleItemClear();
    }

    private boolean isPlayerInChest(PlayerEntity player) {
        ScreenHandler screenHandler = player.currentScreenHandler;
        if (screenHandler instanceof ChestScreenHandler) {
            return true;
        }
        return false;
    }
}
